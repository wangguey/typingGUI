import wx, time 
from random import randint
from datetime import timedelta

class GUI(wx.Frame):
 
    def __init__(self):
        wx.Frame.__init__(self, parent=None, title="輕鬆學拼音", size=(1500,800), style = wx.DEFAULT_FRAME_STYLE)
        fontSize = wx.Font(28, wx.FONTFAMILY_MODERN, wx.FONTSTYLE_NORMAL, wx.NORMAL)
        
        # 配置主選單元件
        menubar = wx.MenuBar()
        typeMenu = wx.Menu()
        gameMenu = wx.Menu() 
        #鍵盤快手元件       
        menubar.Append(typeMenu, '&鍵盤快手')
        typeItem1 = wx.MenuItem(typeMenu, wx.ID_ANY, u"本位列 ", wx.EmptyString, wx.ITEM_NORMAL )
        typeMenu.Append(typeItem1)
        typeItem2 = wx.MenuItem(typeMenu, wx.ID_ANY, u"上一列", wx.EmptyString, wx.ITEM_NORMAL )
        typeMenu.Append(typeItem2)
        typeItem3 = wx.MenuItem(typeMenu, wx.ID_ANY, u"下一列", wx.EmptyString, wx.ITEM_NORMAL )
        typeMenu.Append(typeItem3)
        typeItem4 = wx.MenuItem(typeMenu, wx.ID_ANY, u"全部字母", wx.EmptyString, wx.ITEM_NORMAL )
        typeMenu.Append(typeItem4)
    #    typeItem5 = wx.MenuItem(typeMenu, wx.ID_ANY, u"不指示位置", wx.EmptyString, wx.ITEM_NORMAL )
    #    typeMenu.Append(typeItem5)

        #拼音遊戲元件        
    #    menubar.Append(gameMenu, '&拼音遊戲')
        self.Bind(wx.EVT_MENU, self.ontypeHome, typeItem1)
        self.Bind(wx.EVT_MENU, self.ontypeUpper, typeItem2)
        self.Bind(wx.EVT_MENU, self.ontypeLower, typeItem3)
        self.Bind(wx.EVT_MENU, self.ontypeWhole, typeItem4)
        # self.Bind(wx.EVT_MENU, self.ontypeNoind, typeItem5)
        
        #menuBar
        self.SetMenuBar(menubar) 
        
        self.panelType = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.Size(1500,800 ), wx.TAB_TRAVERSAL)
        self.panelType.SetFont(fontSize)
        self.typeMessage = wx.StaticText(parent=self.panelType, label='鍵盤快手--', pos=(10,10))
        self.typeHeadMessage = wx.StaticText(parent=self.panelType, label='', pos=(200,10))
        self.typeHeadMessage.SetForegroundColour('Blue')     
        self.typeQuestion = wx.StaticText(parent=self.panelType, label='', pos=(555,80))
        self.typeQuestion.SetForegroundColour('Blue')
        self.keyin = wx.TextCtrl(self.panelType, value="",pos=(550,120),size=(26,50))
        self.messageInput = wx.StaticText(parent=self.panelType, label='', pos=(552,123))
        self.messageInput.SetForegroundColour('RED')
        self.endTime = wx.StaticText(parent=self.panelType, label='', pos=(600,180))
        self.endTime.SetBackgroundColour('red')
        self.score = wx.StaticText(parent=self.panelType, label='', pos=(750,180))
        
        self.staticTextTime = wx.StaticText(parent=self.panelType, pos=(1000,200), label='')  
        self.staticTextTime.SetFont(wx.Font(22, wx.FONTFAMILY_MODERN, wx.FONTSTYLE_NORMAL, wx.NORMAL))
        self.messageWarn = wx.StaticText(parent=self.panelType, label='左手食指按ｆ鍵,右手食指按ｊ鍵,隨時歸位', pos=(200,550))
        self.messageWarn.SetFont(wx.Font(22, wx.FONTFAMILY_MODERN, wx.FONTSTYLE_NORMAL, wx.NORMAL))
        to_bmp_imageShow = wx.Image("type.jpg", wx.BITMAP_TYPE_ANY).ConvertToBitmap()  
        self.bitmapShow = wx.StaticBitmap(self.panelType,-1, to_bmp_imageShow, (800, 510))  
        image_width = to_bmp_imageShow.GetWidth()  
        image_height = to_bmp_imageShow.GetHeight() 
        self.timer = wx.Timer(self) # 放一個timer
        
        self.Bind(wx.EVT_TIMER, self.onTimerTick, self.timer)
        self.keyin.Bind(wx.EVT_CHAR, self.onCharEvent)
    
    def onTimerTick(self, e):
        global startTime
        passTime = int(61-(time.time() - startTime))
        self.staticTextTime.SetLabel(str(timedelta(seconds= passTime)))
        if passTime <= 0 :
            self.timer.Stop()
    
    def ontypeHome(self, event):        
        self.homeQuestion()
        self.typeInitial()
        self.typeHeadMessage.SetLabel('本位列一分鐘')
        self.setQuestion()
#        miid = event.GetId()
#        print(miid) 
    
    def ontypeUpper(self, event):        
        self.upperQuestion()
        self.typeInitial()
        self.typeHeadMessage.SetLabel('上一列一分鐘')
        self.setQuestion()

    def ontypeLower(self, event):        
        self.lowerQuestion()
        self.typeInitial()
        self.typeHeadMessage.SetLabel('下一列一分鐘')
        self.setQuestion()
    
    def ontypeWhole(self, event):        
        self.wholeQuestion()
        self.typeInitial()
        self.typeHeadMessage.SetLabel('全部字母一分鐘')
        self.setQuestion()
    
    def homeQuestion(self):
        global question
        question = []
        questionLetter = [97,115,100,102,103,104,106,107,108]
        for i in range(500):
            rndNum = randint(97, 122)
            if rndNum in questionLetter:
                question.append(rndNum) 
        
    def upperQuestion(self):
        global question
        question = []
        questionLetter = [113,119,101,114,116,121,117,105,111,112]
        for i in range(500):
            rndNum = randint(97, 122)
            if rndNum in questionLetter:
                question.append(rndNum) 
    
    def lowerQuestion(self):
        global question
        question = []
        questionLetter = [122,120,99,118,98,110,109]
        for i in range(500):
            rndNum = randint(97, 122)
            if rndNum in questionLetter:
                question.append(rndNum) 
    
    def wholeQuestion(self):
        global question
        question = []
        for i in range(500):
            rndNum = randint(97, 122)
            question.append(rndNum) 
    
    def typeInitial(self):    
        global right, startTime, questionIdx  
        self.refresh() 
        self.keyin.Enable()
        self.keyin.SetValue('')
        self.keyin.SetFocus()
        self.endTime.SetLabel('')
        self.score.SetLabel('')
        startTime = time.time()
        self.timer.Start(700)
        right = 0
        questionIdx = 0
    def refresh(self):
        for i in range(97,123):
            rndLetter = chr(i)
            labelLetter = '  '+ rndLetter +'  '
            Xposition = position[rndLetter][0]
            Yposition = position[rndLetter][1]
            wx.StaticText(parent=self.panelType, label=labelLetter, pos=(Xposition,Yposition)).SetBackgroundColour(color[rndLetter])
        
    def setQuestion(self):
        global rndLetter, Xposition,Yposition
        rndLetter = chr(question[questionIdx])
        self.typeQuestion.SetLabel(rndLetter)
        labelLetter = '  '+ rndLetter +'  '
        Xposition = position[rndLetter][0]
        Yposition = position[rndLetter][1]
        wx.StaticText(parent=self.panelType, label=labelLetter, pos=(Xposition,Yposition)).SetBackgroundColour("gray")
    
    def onCharEvent(self, event):
        global right, questionIdx
        keycode = event.GetKeyCode()
        answer = chr(keycode).lower()
        if answer == rndLetter:
            right += 1
            rightType = "打對"+str(right)+"鍵"
            self.score.SetLabel(rightType)
            labelLetter = '  '+ rndLetter +'  '
            wx.StaticText(parent=self.panelType, label=labelLetter, pos=(Xposition,Yposition)).SetBackgroundColour(color[rndLetter])
            event.Skip()
            self.messageInput.SetLabel(' ')
            questionIdx += 1
            self.setQuestion()
        else: 
            self.messageInput.SetLabel(answer)
        if time.time()-startTime >= 60:
            self.endTime.SetLabel('時間到')
            self.typeQuestion.SetLabel('')
            self.keyin.SetValue('')
            self.keyin.Disable()

    
# Run the program
if __name__ == "__main__":
    global position, color
    position ={'q' : [100, 300], 'w' : [200, 300], 'e' : [300, 300], 'r' : [400, 300],
               't' : [500, 300], 'y' : [600, 300], 'u' : [700, 300], 'i' : [800, 300],
               'o' : [900, 300], 'p' : [1000, 300], 'a' : [150, 370], 's' : [250, 370],
               'd' : [350, 370], 'f' : [450, 370], 'g' : [550, 370], 'h' : [650, 370],
               'j' : [750, 370], 'k' : [850, 370], 'l' : [950, 370], 'z' : [200, 440], 
               'x' : [300, 440], 'c' : [400, 440], 'v' : [500, 440], 'b' : [600, 440],
               'n' : [700, 440], 'm' : [800, 440]}
    color ={'q' : "plum", 'w' : "plum", 'e' : "plum", 'r' : "plum",
               't' : "plum", 'y' : "plum", 'u' : "plum", 'i' : "plum",
               'o' : "plum", 'p' : "plum", 'a' :"green", 's' :"green",
               'd' : "green", 'f' : "purple", 'g' : "green", 'h' : "green",
               'j' : "purple", 'k' : "green", 'l' : "green", 'z' : "coral", 
               'x' : "coral", 'c' : "coral", 'v' : "coral", 'b' : "coral",
               'n' : "coral", 'm' : "coral"}

    app = wx.App()
    frame = GUI()
    frame.Show()
    frame.refresh() 
    app.MainLoop()